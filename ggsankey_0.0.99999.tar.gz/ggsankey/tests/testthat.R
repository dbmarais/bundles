library(testthat)
library(ggsankey)

test_check("ggsankey")
